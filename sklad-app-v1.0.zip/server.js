const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "5mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (req, res) => {
  res.json({ ok: true, version: "1.0.0" });
});

app.listen(PORT, () => {
  console.log(`Склад запущен: http://localhost:${PORT}`);
});
